from telegram import Update
from telegram.ext import ApplicationBuilder,CommandHandler,MessageHandler, ContextTypes,filters

async def help_func(update: Update,context: ContextTypes.DEFAULT_TYPE):
    await context.bot.sendMessage(chat_id=update.effective_chat.id,text="Hallo Sami ! Click auf /Start   --> to Starting !!")

async def start_func(update: Update,context: ContextTypes.DEFAULT_TYPE):
    await context.bot.sendMessage(chat_id=update.effective_chat.id,text="Welcome to New Your Bot")

async  def msg_func(update: Update,context: ContextTypes.DEFAULT_TYPE):
    await context.bot.sendMessage(chat_id=update.effective_chat.id,text="New Message received")

def main():
    application = ApplicationBuilder().token("8409955360:AAF-Pij4NJJ7FkiGmRmDUFg-OVQ-rqN-0f0").build()

    help_handler = CommandHandler('help',  help_func)
    start_handler = CommandHandler('start', start_func)
    message_handler = MessageHandler(filters.ALL, msg_func)

    application.add_handler(help_handler)
    application.add_handler(start_handler)
    application.add_handler(message_handler)

    application.run_polling()

if __name__=="__main__":
    main()




